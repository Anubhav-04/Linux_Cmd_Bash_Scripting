#!/bin/bash

# This is the first shell script

echo "Krishna: Hey Arjuna don't let your emotions to make you weak"
echo "Arjuna : Hey Krishna how would i control my emotions?"
echo "Krishna: To vow for your Dharma you have to be strong....."
